#include<iostream>
using namespace std;

int main ()
{
    char x;
    cout <<"enter a character :\t";
    cin>>x;
    cout <<"you entered : \t"<<x<<endl;

    return 0;
}