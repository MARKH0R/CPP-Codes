#include<iostream>
using namespace std;

int main ()
{
    char ch;
    cout <<"enter a character: \t";
    cin>> ch;
    cout << "ASCII Value :\t"<<int (ch)<<endl;
    
    return 0;
}    

