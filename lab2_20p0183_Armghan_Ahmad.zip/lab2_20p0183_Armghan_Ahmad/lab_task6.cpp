#include<iostream>
using namespace std;

int main ()
{
    bool j;
    char s;
    int A;
    cout <<"Enter MArtial status:\t";
    cin >>s;
    cout <<"Enter age:\t";
    cin >> A;
    cout <<"Enter job status:\t";
    cin >>j;
    if (s == 'u')
    {
        if (A <= 25)#include<iostream>
using namespace std;

int main ()
{
    bool j;
    char s;
    int A;
    cout <<"Enter MArtial status:\t";
    cin >>s;
    cout <<"Enter age:\t";
    cin >> A;
    cout <<"Enter job status:\t";
    cin >>j;
    if (s == 'u')
    {
        if (A <= 25)
        {
            if (j==false)
            {
                cout <<"eligibal for loan"<<endl;
            }
        }
    }
    else
    {
        cout <<"NOT eligibal for Loan"<<endl;
    }

    return 0;
}  
  
  

        {
            if (j==false)
            {
                cout <<"eligibal for loan"<<endl;
            }
        }
    }
    else
    {
        cout <<"NOT eligibal for Loan"<<endl;
    }

    return 0;
}  
  
  
