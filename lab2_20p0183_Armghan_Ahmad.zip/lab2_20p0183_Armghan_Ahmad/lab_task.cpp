#include <iostream>
using namespace std;

int main ()
{
    char ch;
    ch='a';
    cout <<"The character is : "<<ch<<endl;
    return 0;
}