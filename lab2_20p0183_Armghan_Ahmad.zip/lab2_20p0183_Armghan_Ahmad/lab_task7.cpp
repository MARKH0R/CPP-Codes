#include<iostream>
using namespace std;
int main()
{
    int a,b;
    cout <<"enter two number :\n";
    cin >>a>>b;
    cout <<(a>b?"A is greater":"B is greater");

return 0;
}