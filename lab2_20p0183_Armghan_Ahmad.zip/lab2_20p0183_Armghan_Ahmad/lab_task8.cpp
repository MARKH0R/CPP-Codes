#include<iostream>
using namespace std;

int main()
{
    
    char ch;
    cout <<"Enter grades :\t";
    cin >> ch;
    switch (ch)
    {
        case 'A':
        case 'a':
        cout <<"Excellent";
        break;
        case 'B':
        case 'b':
        cout <<"very good";
        break;
        case 'C':
        case 'c':
        cout << "Good";
        break;
        case 'D':
        case 'd':
        cout<<"poor";
        break;
        case 'F':
        case 'f':
        cout<<"fail";
        default:
        cout<<"enter GRADES FORM 'A' TO 'F' ";


    }


return 0;
}