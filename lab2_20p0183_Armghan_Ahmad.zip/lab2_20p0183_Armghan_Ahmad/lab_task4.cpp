#include<iostream>
using namespace std;

int main ()
{
    int x,y ;
    cout <<"enter two integer:\n";
    cin>> x>>y;
    if (x == y)
    {
        cout <<x<<" is equal to "<<y<<endl;
    }
    if (x != y)
    {
        cout <<x<<" is not equal to "<<y<<endl;

    }
      if (x<=y)
    {
        cout <<x<<" is less then "<<y<<endl;
    }
    if (x>=y)
    {
        cout <<x<<" is greater then "<<y<<endl;
    }


return 0;
}  

