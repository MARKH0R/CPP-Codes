nclude <iostream>
 using namespace std;

 int main ()
 {
     float S ,D;
     cout << "enter your salary :\t";
     cin >>S;

     if (S < 10000)
     {
         cout <<"Your salary is less then 10,000 so there is no deduction.\n your actual salary = "<<S<<endl;
     }
     else if (S >= 10000 && S <= 20000 )
     {
         D=S-1000;
         cout <<"Your salary = "<<D<<endl;
     }
     else 
     {
         D =S*0.07;
         cout <<"your salary is =" << S-D << endl; 
     }

     return 0;
 }
