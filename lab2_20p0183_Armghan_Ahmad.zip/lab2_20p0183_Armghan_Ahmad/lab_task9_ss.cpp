#include<iostream>
using namespace std;

int main ()
{
int a ,b ;
cout << "Enter two positive number :\n";
cin >>a>>b;
switch (a>b)
{
    case 0:
    cout <<a<<" number is less then  "<<b<<endl;
    cout << b<<" number is greater then "<< a<<endl;
    break;
    case 1:
    cout << a<<" number is greater then "<< b<<endl;
    cout <<b<<" number is less then  "<<a<<endl;
    break;
    default:
    cout << "Enter two positive number "<<endl;
}

return 0 ;
}
