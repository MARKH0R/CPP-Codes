#include<iostream>

using namespace std;

int main ()
{
    int IN;
    cout<<"Enter any number :\t";
    cin>>IN;

    if (IN == 0 )
    {
        cout<<IN<<" is a prime number"<<endl;
        
    }
    else if (IN == 1)
    {
        cout <<IN<< " is not a prime number."<< endl;
    }    
    else 
    {
        for (int i = 2; i < IN/2; i++)
        {
           if (IN%i==0)
            {
                cout<<IN<<" not a prime number."<< endl;
                break;
            }
            else
            {
                cout<<IN<<" a prime number."<< endl;
                break;
            }
            
        }
    }
    return 0;
}