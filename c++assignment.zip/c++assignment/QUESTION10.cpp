#include<iostream>

using namespace std;

int main()
{

	
	for (int i=1;i<=1000;i++)
	{        
		for(int j=999;j<=1000;j--)
		{
			if (i+j==1000)
			{
				cout<<i<<"+"<<j<<"=1000"<<endl;
			}
		}
	}
return 0;
}