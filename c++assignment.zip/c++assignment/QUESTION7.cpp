#include<iostream>

using namespace std;

int main ()
{
    int a,b,c,y;
    cout<< "Enter three numbers:\t"<<endl;
    cin>> a;
    cin>> b;
    cin>> c;
    cout <<"Your number forward: "<<a<<b<<c<<endl;
    y=a;
    a=c;
    c=y;
    cout<< "Your number reversed: "<<a<<b<<c<<endl;
    return 0;
}