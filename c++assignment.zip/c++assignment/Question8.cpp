#include<cmath>
/*
Question 8:
Write the definition of a function that takes as input three decimal numbers (e.g. a, b, c)
and returns the first number multiplied by the second number to the power of third
number i.e. returns (a*b)c.
*/

#include<iostream>

using namespace std;


int main()
{
    int first_number, secound_number,product, result_power,finalresult;


    cout << "Enter first number :\t";
    cin >> first_number;

    cout << "Enter secound number :\t";
    cin >> secound_number;
    cout << "Enter third number :\t";
    cin>>result_power;
    cout <<first_number<<"*"<<secound_number<<endl;

    product=first_number*secound_number;

    finalresult= pow(product,result_power);
    cout <<"(" <<first_number<<"*"<<secound_number<<")" << "^" << result_power << " = " << finalresult<<endl;

    return 0;
} 