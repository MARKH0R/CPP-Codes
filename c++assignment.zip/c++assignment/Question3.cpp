#include <iostream>
using namespace std;

void digitCount(long long  int &num)
{
    int e = 0, z = 0, o = 0, x = 0;
    for (int i = 0; i <= num; i++)
    {
        x= num % 10;    
        if(x%2 == 0 and x!=0)
        {
            e=e+1;
            num = num / 10;
        }
        else if(x%2!=0)
        {
            o=o+1;
            num = num / 10;
        }
        else
        {
            z=z+1;
            num = num / 10;
        }  
    }

    cout << "No of zeros Digits = " << z<< " No of odd Digits = " << o << " No of even Digits = " << e <<endl;
   

}


int main ()
{
    long long int num;

    cout <<"Enter any No.:\t ";
    cin >>num;

    digitCount(num);

    return 0;
}