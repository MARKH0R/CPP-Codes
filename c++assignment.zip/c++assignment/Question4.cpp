#include <iostream>
 
using namespace std;

int main()
{int n,sum=0,f;
    cout<< "enter the number between 1 and 1000 :\t";
    cin>> n;
    for (int i = 1; i < n ; i++)
    {   
        f=n%i;
        if (n%i==0)
        {
            sum=sum+i;
            cout<<i<<",\t"   ;
        }
        
         
    }
    cout <<" are the factors of "<<n<<endl;
    if (sum==n)
        {
            cout<<n<<" is perfect number"<<endl;
        }
        else
        {
            cout<<n<<" is not a perfect number"<<endl;
        }
    return 0;
}
