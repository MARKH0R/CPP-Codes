/*Question 6:
Write a program which get char data as input and then tell whether the given character
is a vowel or consonant.*/
#include <iostream>

using namespace std;

int main()
{
    char X;
    cout<<"Enter any cheracter\t";
    cin>>X;
    switch (X)
    {
        case 'A' :
            cout <<X<<" is vowel"<<endl;
            break;
        case 'E' :
            cout <<X<<" is vowel"<<endl;
            break;
        case 'I' :
            cout <<X<<" is vowel"<<endl;
            break;
        case 'O' :
            cout <<X<<"  is vowel"<<endl;
            break;
        case 'U' :
            cout <<X<<" is vowel"<<endl;
            break;
        case 'a' :
            cout <<X<<" is vowel"<<endl;
            break;
        case 'e' :
            cout <<X<<" is vowel"<<endl;
            break;
        case 'i' :
            cout <<X<<" is vowel"<<endl;
            break;
        case 'o' :
            cout <<X<<" is vowel"<<endl;
            break;
        case 'u' :
            cout <<X<<" is vowel"<<endl;
            break;
        default:
            cout <<X<<" is not a vowel "<<X<<" is consonant"<<endl;
        
    }
    return 0;

}