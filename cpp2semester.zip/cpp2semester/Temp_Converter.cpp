#include <iostream>
using namespace std;


float TempIntoCelcius (float F )
 {
      return ((F-32)*5)/9;   
 }

float TempIntoFahrinheit (float C)
{
    return  (1.8 * C) + 32;

}

int main ()
{   float F,C,c,f;
    cout << "Enter temperature in Fahrenheit:\t";
    cin >> F ;
    C=TempIntoCelcius(F);
    cout << "Temperature in celcius =\t"<<C<<endl;
    //output for Fahrenheit 
    cout << "Enter the temperature in Celcius =\t ";
    cin >>c;
    f=TempIntoFahrinheit(c);//function call
    cout <<"Temperaturn in fariinhite is =\t"<<f<<endl;

    return 0;
}
