#include<iostream>
using namespace std;

int main ()
{
    int number, count, result;
    cout<<"Enter a limit of table :\t";
    cin >> count ;
    cout<< "Enter a number for table ;\t";
    cin>> number;
    
    for (int i=1;count>=i;i++)
    {
        cout<<number <<"*"<<i<<"="<<i*number<<endl;
    }


}
