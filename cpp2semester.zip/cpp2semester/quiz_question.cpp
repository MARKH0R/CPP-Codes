#include <iostream>
using namespace std;

int main()
{
    float a ,b ,c ,ts;
    cout<<"enter the angles of triangle :\n";
    cin>> a>>b>>c;
    ts = a+b+c;
    if (ts == 180)
    {
        cout <<"Triangle is valid";
    }
    else 
    {
        cout <<"triangle is not valid"<<endl;
    }
 
 
 // question 7:
    int year;
    cout <<"Enter year:\t";
    cin>>year;
    if (year % 400 == 0 )  
    {
        if (year % 100 == 0 )
        {
            if (year % 4 == 0 )
            {
                cout <<year<<" is a leap year";
            }
            else
            {
                cout<<year<<" is Not a leap year";
            }
        }
        else
            {
                cout<<year<<" is a leap year";
            }
    
    }
    else
    {
        cout <<year<<" is not a leap year"<<endl;
    }
// question 7

int 





return 0;
}