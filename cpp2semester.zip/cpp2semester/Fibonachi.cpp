#include<iostream>
using namespace std;

int main()
{
    int num , a = 0 , b = 1,c ;
    cout <<"Enter the number to find fibonacci  serics;\t";
    cin>>num;
    cout <<"Fibonacci Sequence of the given number : "<<a<<","<<b<<",";
    for (int i = 2;num >= i ; i++)
    {
        
        c=a+b;
        a=b;
        b=c;
        cout << c<<",";
        
    }
    cout<<"..."<<endl;
}