#include <iostream>
using namespace std;



int main()
{
    int number, count ;

    /*questions for practice to learn cpp*/
    
    //ood number less then 10
    
    for (int i =1;i<=10;i++)
    {
        cout<<i<<endl;
    }
    for( int i =1;i<=10;i++)
    {
        if (i % 2 != 0)
        {
            cout <<i<< endl;
        }
    }



    //table 
    cout<<"Enter a limit of table :\t";
    cin >> count ;
    cout<< "Enter a number for table ;\t";
    cin>> number;
    
    for (int i=1;count>=i;i++)
    {
        cout<<number <<"*"<<i<<"="<<i*number<<endl;
    }
    
    //table from 1 to 10
    for (int num=1;num<=10;num++)
    {
        cout << "Table of "<<num<<endl;
        for (int i=1;i<=10;i++)
        {
            cout<<num <<"*"<<i<<"="<<i*num<<endl;
        }
    }


    cout<<"sum from 1 to 10 is :\t";
int i = 1,sum=0;
   while (i<=10)
   {
       sum=sum+i;
       i++;
   }
   cout<<sum<<endl;
    //factorial table
    cout<< "calculateing 10!"<<endl;
    int fac=1;
    for (int i=1;i<=10;i++)
    {
        fac=fac*i;
    } 
    cout<< fac<<endl;
    //sum from 10 to 30
    int  Sum=0;
    for (int num=10 ;num <= 30 ; num++)
    {
        Sum=Sum+num;
    }
    cout<<"sum from 10 to 30 is =\t"<<Sum<<endl;

   


    return 0;
}
 