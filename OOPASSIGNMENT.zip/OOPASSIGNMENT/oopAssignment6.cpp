#include <iostream>
using namespace std;

int main ()
{
    int m ,n, a,b ;
    cout <<"Enter the order of first the matrics :\n";
    cin>>m>>n;

    cout <<"Enter the order of secound the matrics :\n";
    cin>>a>>b;
    cout <<endl;

    int myArray1[m][n];
    int myArray2[a][b];
    
    cout <<"enter element of array one :\n";
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            
            cin >> myArray1[i][j];
            
        }
        cout<<endl;
    }

    cout <<"enter element of array two :\n";
    for (int i = 0; i < a; i++)
    {
        for (int j = 0; j < b; j++)
        {
            
            cin >> myArray2[i][j];
            
        }
        cout<<endl;
    }

    cout<<"The element of first array are :\n";
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            
            cout << myArray1[i][j]<<" ";
            
        }
        cout<<endl;
    }

    cout<<"The element of secound array are :\n";
    for (int i = 0; i < a; i++)
    {
        for (int j = 0; j < b; j++)
        {
            
            cout << myArray2[i][j]<<" ";
            
        }
        cout<<endl;
    }
    cout << "sum of two matrixs are : \n"<<endl;
    for (int i = 0; i < a; i++)
    {
        for (int j = 0; j < b; j++)
        {
            
            cout << myArray1[i][j] + myArray2[i][j]<<" ";
            
        }
        cout<<endl;
    }
    



    system ("pause");
    return 0;
}