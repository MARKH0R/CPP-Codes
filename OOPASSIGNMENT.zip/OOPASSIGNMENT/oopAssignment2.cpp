#include<iostream>
 
using namespace std;

int dignalsum1 (int size ,   int array1[5][5])
{
    int dig1S =0;
    for(int i = 1 ; i <= size; ++i)
	{	for(int j = 1 ; j <= size; ++j)
		{
			if(i == j)
			{
                dig1S+=array1[i][j];
            }    
			
		}
    }

    return dig1S;
}

int dignalsum2 (int size ,   int array1[5][5])
{
    int dig2S =0;
    for(int i = 1 ; i <= size; ++i)
	{	for(int j = 1 ; j <= size; ++j)
		{
			 
			if(i+j == (size-1))
			{
                dig2S+=array1[i][j];
            }
		}
    }
    return dig2S;
}

int main()
{
	int array1[5][5];
    int size ,D1 ,D2;
	cout<<"Enter size of the square matrix \" maximum size would be 5 \": \t";
	cin>>size;
    cout<<endl;
	cout<<"Enter the Matrix row wise:\n";
	
	for(int i=1; i <= size ; i++)
	{
        for(int j=1 ; j<=size ; ++j)
			{
                cin>>array1[i][j];
            }
            cout<<endl;
        }	
    }
    D1 = dignalsum1 (size , array1 [5][5] );
    D2 = dignalsum2 ( size  , array1[5][5]);

	cout<<"\nSum of 1st diagonal is "<< D1;
	cout<<"\nSum of 2nd diagonal is "<< D2;
 
	return 0;
}