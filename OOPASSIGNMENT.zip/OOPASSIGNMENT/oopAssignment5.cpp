#include <iostream>
using namespace std;


int DispMRowMCol(int S,int Arr[S][S]) 
{ 
    int mid ; 
    mid=S/2;
    cout<<"\n Middle Row:"; 
    for(int i=0;i<S;i++)
    {
        cout <<Arr[mid][i]<<" ";
    }
    cout<<"\n Middle colum:"; 
    for(int i=0;i<S;i++)
    {
        cout<< Arr[i][mid]<<" ";
    }
}
int main ()
{ 
    int a; 
    int Array[a][a];
     
    cout <<"enter odd orde of matrix e.g 3 x 3, 5 x 5, 7 x 7 etc… :\n";
    cin >>a;
    for (int i = 1; i <= a; i++)
    {
        for (int j = 1; j <= a; j++)
        {
            cin>>Array[i][j];
        }
        cout<<endl;
        
    }
    
    cout << DispMRowMCol(a, Array[a][a]) ;
    
    return 0;
}
