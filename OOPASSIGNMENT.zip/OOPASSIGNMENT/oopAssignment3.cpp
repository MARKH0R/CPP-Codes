#include <iostream>
using namespace std;

/*
Write a user-defined function in C++ to display the multiplication of row element of 
two-dimensional array A[4][6] containing integer.
*/
int  RowMulti(int A[4][6])
{ 
    int Mul[4]; 
    for(int i=0;i<4;i++) 
    { 
        Mul[i]=1; 
        for(int j=0;j<6;j++) 
        Mul[i]*=A[i][j]; 
        cout<<"Product of row"<<i+1<<"="<<Mul[i]<<endl;
    }
    return 0;
}


int main ()
{
    int A[4][6];

    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            cin >>A[i][j];
        }
        cout <<endl;
    }
    RowMulti ( A[4][6] );

    system ("pause");
    return 0;
}
