#include <iostream>
using namespace std;

int fun1(int array[3][3])
{
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            cout<<"array["<<i<<"]["<<j<<"] = ";
            cin>>array[i][j];
        }
    }
}
    
int fun2(int Array[3][3])
{
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
        cout<<array[i][j]<<" ";
        }
        cout<<endl;
    }
}
int fun3(int array[3][3])
{ 
    int s=0;
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
        s+=array[i][j];
        }
    }
        cout<<"Sum = "<<s<<endl;
}

int fun4(int array[3][3])
{
     int r=1;
     for(int i=0;i<3;i++)
    {
        int rs = 0;
        for(int j=0;j<3;j++)
        {
            cout<<array[i][j]<<" ";
            rs+=array[i][j];
        }
        cout<<" sum  of row "<<r<<" is "<<rs<<endl;
        r++;
    }
}
int fun5(int array[3][3])
{
int c=1;
     for(int i=0;i<3;i++)
    {
        int cs = 0;
        for(int j=0;j<3;j++)
        {
            cout<<array[j][i]<<" ";
            cs+=array[j][i];
        }
        cout<<" sum of column "<<c<< " is "<<cs<<endl;
        c++;
    }
}
int fun6(int array[3][3])
{
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            cout<<array[j][i]<<" ";
        }
            cout<<endl;
    }
}

int main()

{   
    while(true)
    {
        int array[3][3];
        string data;
        string data2;
        cout<<"press 'A' for to take elements as data\npress 'B' for display\npress 'C' for sum of matrix \npress 'D' sum of row elements\npress 'E' for sum of column elements\npress 'F' for transpose of matrix\n";
        cin>>data;
        if(data=="A")fun1(array);
        else if (data=="B")fun2(array);
        else if (data=="C")fun3(array);
        else if (data=="D")fun4(array);
        else if (data=="E")fun5(array);
        else if (data=="F")fun6(array);
        cout<<"Will u do an other ooperation (y/n)  ";
        cin>>data2;
        if(data2=="n")
        {
            break;
        }
    }
    system ("pause");
    return 0;
}