#include<iostream>
 
using namespace std;

int Upper-half(int b[][10],int N)

{ 
     
    for(int i=N;i>0;i--) 
    { 
        for(int j=N;j>0;j--) 
        { 
            if(i>=j) 
            {
                cout<<b[i][j]<<" ";
            }
            else cout<<" "; 
            }
                cout<<"\n"; 
            }
        } 
    }

}
int main ()
{

    cout <<Upper-half(int b[][10],int N);
}